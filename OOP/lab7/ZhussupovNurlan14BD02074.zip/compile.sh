javac Sorting.java
javac BubbleSort.java
javac Sort.java
javac Main.java
javac ChooseSort.java
java Main
