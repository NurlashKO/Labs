public interface Sort
{
    public void sort(int[] a);
}

