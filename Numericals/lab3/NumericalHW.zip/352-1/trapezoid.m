function y = trapezoid(f, a, b, h)
    y=h/2*(f(a) + f(b));
end;
