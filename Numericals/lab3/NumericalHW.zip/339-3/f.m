function y = f(x)
    if (x == 4.90)
        y = 1.5892;
    end;
    if (x == 4.95)
        y = 1.5994;
    end;
    if (x == 5.00)
        y = 1.6094;
    end;
    if (x == 5.05)
        y = 1.6194;
    end;
    if (x == 5.10)
        y = 1.6269;
    end;
end;
