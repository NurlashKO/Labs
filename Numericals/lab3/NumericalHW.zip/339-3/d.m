format long;
%% Each method gives us next answers
correctAnswer = -0.04;
A = 0;
B = -0.269999999999992;
C = 0.0900000000000863; 
error1 = abs(correctAnswer - A)
error2 = abs(correctAnswer - B)
error3 = abs(correctAnswer - C)
error1 =  0.0400000000000000
error2 =  0.229999999999992
error3 =  0.130000000000086
%% Its clear that answer (A) is most accurate
