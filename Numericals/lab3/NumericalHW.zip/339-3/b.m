format long;
x = 5;
h = 0.1;
(f(x + h) - 2*f(x) + f(x - h)) / (h**2)
