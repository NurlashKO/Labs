h = 0.1;
x = 0.1;
(fb(x + h) - fb(x - h))/2/h
x = 0.2;
(fb(x + h) - fb(x - h))/2/h
