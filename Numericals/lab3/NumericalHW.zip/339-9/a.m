h = 0.1;
x = 0.1;
(fa(x + h) - fa(x - h))/2/h
x = 0.2;
(fa(x + h) - fa(x - h))/2/h
